# L Drago Android Assistant (prototype)

This is an Android Studio project for a Realme C33 / Android 13. It is source code, **not a prebuilt APK**.

## Current features
- Tap-to-speak using Android's installed speech recognition service
- Prototype "Hey L Drago" foreground listener
- Spoken replies using Android Text-to-Speech
- Open YouTube, Chrome and Android Settings
- Launch the alarm app
- Google web search
- Time query

## Important limitations
- The wake-word implementation is a prototype using Android `SpeechRecognizer`, not a dedicated offline hotword engine. Android speech recognition can time out, require network access, stop in the background, and consume battery. It is not guaranteed to continuously detect the wake phrase.
- Android 13 asks for microphone and notification permission. Start the listener while the app is visible. A persistent notification is shown while the microphone service is active.
- This starter does not yet contain a cloud AI integration. Do not put a private API key into public source code. A secure backend is recommended for AI answers.
- Android/Realme may restrict background operation. Check Settings > Apps > L Drago > Battery and allow background activity if the option exists. Do not disable Android privacy indicators or microphone controls.

## Build an APK with Android Studio
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Gradle to sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be under `app/build/outputs/apk/debug/`.

## Install on your Realme C33
Transfer the generated APK to your phone, open it, and allow installation from that file manager when Android asks. Install only APKs you built yourself or trust.

## Package details
Application ID: `com.ldrago.assistant`
Minimum Android: 8.0 (API 26)
Target Android: 14 (API 34)
Version: 0.1 prototype
