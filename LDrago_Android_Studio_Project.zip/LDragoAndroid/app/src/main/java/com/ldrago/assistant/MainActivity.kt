package com.ldrago.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        handleWakeIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWakeIntent(intent)
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(0xFF101522.toInt())
        }
        val title = TextView(this).apply {
            text = "L DRAGO"
            textSize = 32f
            setTextColor(0xFF75C9FF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Your assistant is ready"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        val listen = Button(this).apply {
            text = "TAP TO SPEAK"
            setOnClickListener { startOneShotListening() }
        }
        val wake = Button(this).apply {
            text = "START 'HEY L DRAGO' WAKE LISTENING"
            setOnClickListener { startWakeService() }
        }
        val stop = Button(this).apply {
            text = "STOP WAKE LISTENING"
            setOnClickListener { stopService(Intent(this@MainActivity, WakeService::class.java)); status.text = "Wake listening stopped" }
        }
        output = TextView(this).apply {
            text = "Commands: open YouTube, open Chrome, set an alarm, search for ..., or ask a question."
            textSize = 15f
            setTextColor(0xFFE6EAF2.toInt())
            setPadding(0, 24, 0, 0)
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(listen)
        layout.addView(wake)
        layout.addView(stop)
        layout.addView(output)
        setContentView(layout)
    }

    private fun hasAudioPermission() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestAudio() {
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 101)
    }

    private fun startWakeService() {
        if (!hasAudioPermission()) { requestAudio(); return }
        try {
            startForegroundService(Intent(this, WakeService::class.java))
            status.text = "Wake listener starting. Keep the notification visible."
        } catch (e: Exception) {
            status.text = "Could not start listener: ${e.localizedMessage}"
        }
    }

    private fun startOneShotListening() {
        if (!hasAudioPermission()) { requestAudio(); return }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to L Drago")
        }
        try { startActivityForResult(i, 102) } catch (_: Exception) {
            status.text = "Speech recognition is not available on this phone."
        }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 102 && resultCode == RESULT_OK) {
            val phrase = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (phrase != null) runCommand(phrase)
        }
    }

    private fun handleWakeIntent(i: Intent?) {
        val phrase = i?.getStringExtra("recognized_command") ?: return
        runCommand(phrase)
    }

    fun runCommand(raw: String) {
        val command = raw.lowercase(Locale.ROOT).trim()
        output.text = "You said: $raw"
        when {
            command.contains("open youtube") -> openPackage("com.google.android.youtube", "YouTube")
            command.contains("open chrome") -> openPackage("com.android.chrome", "Chrome")
            command.contains("open settings") -> startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            command.contains("set an alarm") || command.contains("set alarm") -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_MESSAGE, "L Drago")
                if (i.resolveActivity(packageManager) != null) startActivity(i) else speak("No clock app found")
            }
            command.startsWith("search for ") || command.startsWith("search ") -> {
                val q = command.removePrefix("search for ").removePrefix("search ")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
            }
            command.contains("what time") -> speak("The time is " + java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date()))
            else -> speak("I heard $raw. For general AI answers, connect an AI service in a future version.")
        }
    }

    private fun openPackage(pkg: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch) else speak("$label is not installed.")
    }

    private fun speak(text: String) {
        output.text = text
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ldrago_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale.getDefault()
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
